<?php
    include("config.php");
    session_start();
    ob_start();
    $key = "aplikasi-hnp";
    $response = array();
    if (isset($_POST['function'])){
        $function = $_POST['function'];
        $userkey = $_POST['key'];
        if($userkey==$key){
            if($function=="ListData"){
                $sql = "SELECT * FROM tb_data ORDER BY kode ASC";
                if ($result=mysqli_query($db,$sql)){
                    while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
                        $listIsi = array();
                        $listIsi['kode'] = $row['kode'];
                        $listIsi['gejala'] = $row['gejala'];
                        $listIsi['P001'] = $row['P001'];
                        $listIsi['P002'] = $row['P002'];
                        $listIsi['P003'] = $row['P003'];
                        $listIsi['P004'] = $row['P004'];
                        $listIsi['densitas'] = $row['densitas'];
                        $listIsi['plausibility'] = $row['plausibility'];
                        $response[] = $listIsi;
                    }
                    mysqli_free_result($result);
                }
                $result = array();
                $result['hasil'] = $response;
                print(json_encode($result));
            }else if($function=="Diagnosa"){
                $nama = $_POST['nama'];
                $umur = $_POST['umur'];
                $diagnosa = $_POST['diagnosa'];
                $sql = "INSERT INTO tb_diagnosa (nama,umur,diagnosa) VALUES ('$nama','$umur','$diagnosa')";
                $result = mysqli_query($db,$sql);
                if($result){
                    $response["message"] = 'Diagnosa berhasil disimpan';
                    $response["success"] = 1;
                }else{
                    $response["message"] = 'Diagnosa gagal disimpan!';
                    $response["success"] = 0;
                }
                $result = array();
                $result['hasil'] = $response;
                print(json_encode($result));
            }else if($function=="ListHasil"){
                $sqlCek = "SELECT COUNT(*) AS jml FROM tb_diagnosa";
                $resultCek = mysqli_query($db,$sqlCek);
                $rowCek = mysqli_fetch_array($resultCek,MYSQLI_ASSOC);
                $jml = $rowCek['jml'];
                $sql = "SELECT * FROM tb_diagnosa GROUP BY diagnosa ORDER BY diagnosa ASC";
                if ($result=mysqli_query($db,$sql)){
                    while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
                        $listIsi = array();
                        // $listIsi['recid'] = $row['recid'];
                        // $listIsi['nama'] = $row['nama'];
                        // $listIsi['umur'] = $row['umur'];
                        $listIsi['diagnosa'] = $row['diagnosa'];
                        //Cek Jumlah
                        $sqlCek = "SELECT COUNT(*) AS jml FROM tb_diagnosa WHERE diagnosa = '$row[diagnosa]'";
                        $resultCek = mysqli_query($db,$sqlCek);
                        $rowCek = mysqli_fetch_array($resultCek,MYSQLI_ASSOC);
                        $listIsi['jumlah'] = $rowCek['jml'];//."/".$jml;
                        $listIsi['persen'] = number_format(((int)$rowCek['jml'] / (int)$jml) * 100,2);
                        $response[] = $listIsi;
                    }
                    mysqli_free_result($result);
                }
                $result = array();
                $result['hasil'] = $response;
                print(json_encode($result));
            }
        }else{
            // no function
            $response["success"] = 0;
            $response["message"] = "Function missing";
            print(json_encode($response));    
        } 
    }else{
        // no function
        $response["success"] = 0;
        $response["message"] = "Function missing";
        print(json_encode($response));
    }
?> 