<?php
	echo '<p style="text-align:center;font-size:20px;"><b>Penyakit HNP</b>';
	echo '<p style="text-align:justify;font-size:16px;">
	&nbsp;&nbsp;&nbsp;&nbsp;Tulang belakang (vertebra) tersusun atas ruas-ruas tulang yang dihubungkan oleh sendi yang membentuk satu kesatuan, mulai dari tulang leher (servikalis) sampai tulang ekor (oskoksigis). Ruas tulang bagian atas akan terhubung dengan ruas tulang dibawahnya oleh semacam bantalan yang disebut sebagai sendi tulang belakang (diskus invertebralis).<br>
	&nbsp;&nbsp;&nbsp;&nbsp;Didalam diskus invertebralis tersebut, terdapat semacam bahan pengisi yang mirip jeli kenyal yang disebut sebagai nukleus pulposus, bantalan tersebut berfungsi sebagai shock breaker (peredam getar) yang memungkinkan tulang belakang untuk bergerak lentur.<br>
	&nbsp;&nbsp;&nbsp;&nbsp;HNP adalah keadaan dimana nukleus pulposus keluar menonjol untuk kemudian menekan ke arah kanalis spinalis melalui anulus fibrosis yang robek. Penyakit ini biasa disebut dengan syaraf kejepit. Biasanya penyakit ini diawali dengan sakit nyeri pinggang yang bisa disebabkan karena infeksi pada otot atau tulang belakang, trauma atau benturan yang hebat pada pinggang, kelainan pada tulang belakang.<br>
	&nbsp;&nbsp;&nbsp;&nbsp;Bagi masyarakat umum yang minim pengetahuan terhadap suatu penyakit, nyeri pinggang dianggap nyeri biasa yang hanya dibiarkan saja dan tidak ada pengobatan lebih lanjut. Jika gejala penyakit ini tidak ditangani dengan semestinya maka dapat menimbulkan penyakit yang lebih serius yang mengarah ke penyakit HNP.<br>
	&nbsp;&nbsp;&nbsp;&nbsp;Sistem pakar yang merupakan sistem yang berisi pengetahuan dari seorang pakar dapat digunakan untuk mendeteksi gelaja-gelaja penyakit HNP. Dengan menambahkan knowledge base dan mesin inferensi terhadap penyakit HNP, sistem pakar berbasis android  ini dapat diakses dimanapun dan kapanpun oleh siapapun yang membutuhkan. Sistem ini memberikan hasil akhir diagnosa kemungkinan penyakit dan saran penanggulangan.';
	echo '<p style="text-align:center;"><img src="foto/hnp.jpg" width="300"/>';
	echo '<p style="text-align:center;font-size:20px;"><b>Rekomendasi Dokter</b>';
	echo '<p style="text-align:left;font-size:16px;"><b>1. HNP Lumbal</b>';
	echo '<p style="text-align:left;font-size:16px;">
	<ul>
        <li>Lakukan olahraga renang gaya dada secara teratur</li>
        <li>Hindari berdiri atau duduk terlalu lama.</li>
        <li>Konsumsi obat anti nyeri ringan seperti ibuprofen atau paracetamol</li>
        <li>Lakukan fisioterapi bagian punggung</li>
        <li>Perbanyak istirahat (bed rest)</li>
        <li>Gunakan penyangga punggung (lumbar support)</li>
        <li>Menjaga postur tubuh</li>
    </ul>';
	echo '<p style="text-align:left;font-size:16px;"><b>2. HNP Servikal</b>';
	echo '<p style="text-align:left;font-size:16px;">
	<ul>
        <li>Aktivitas menggerakkan kepala</li>
        <li>Hindari berdiri atau duduk terlalu lama</li>
        <li>Konsumsi obat anti nyeri ringan seperti ibuprofen atau paracetamol</li>
        <li>Lakukan fisioterapi bagian leher</li>
        <li>Perbanyak istirahat</li>
        <li>Gunakan penyangga leher (cervical collar)</li>
        <li>Menjaga postur tubuh</li>
    </ul>';
	echo '<p style="text-align:left;font-size:16px;"><b>3. Nyeri Pinggang Biasa</b>';
	echo '<p style="text-align:left;font-size:16px;">
	<ul>
        <li>Lakukan peregangan punggung dan pinggang</li>
        <li>Lakukan pemijatan di daerah punggung</li>
        <li>Berendam dalam air hangat</li>
        <li>Oleskan minyak, balsem, atau salep hangat untuk relaksasi otot</li>
    </ul>';
	echo '<p style="text-align:left;font-size:16px;"><b>4. Nyeri Leher Biasa</b>';
	echo '<p style="text-align:left;font-size:16px;">
	<ul>
        <li>Lakukan peregangan leher</li>
        <li>Lakukan pemijatan di daerah leher dan bahu</li>
        <li>Oleskan minyak, balsem, atau salep hangat untuk relaksasi otot</li>
        <li>Kompres Leher Dengan Air Hangat</li>
    </ul>';
// 	if($row['subkingdom']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subkingdom : </b>'.$row['subkingdom'].'';
// 	}
// 	if($row['superfilum']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Superfilum : </b>'.$row['superfilum'].'';
// 	}
// 	if($row['filum']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Filum : </b>'.$row['filum'].'';
// 	}
// 	if($row['subfilum']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subfilum : </b>'.$row['subfilum'].'';
// 	}
// 	if($row['kelas']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Kelas : </b>'.$row['kelas'].'';
// 	}
// 	if($row['subkelas']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subkelas : </b>'.$row['subkelas'].'';
// 	}
// 	if($row['infrakelas']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Infrakelas : </b>'.$row['infrakelas'].'';
// 	}
// 	if($row['infrakelas']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subkingdom : </b>'.$row['infrakelas'].'';
// 	}
// 	if($row['ordo']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Ordo : </b>'.$row['ordo'].'';
// 	}
// 	if($row['subordo']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subordo : </b>'.$row['subordo'].'';
// 	}
// 	if($row['superfamili']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Superfamili : </b>'.$row['superfamili'].'';
// 	}
// 	if($row['famili']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Famili : </b>'.$row['famili'].'';
// 	}
// 	if($row['subfamili']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subfamili : </b>'.$row['subfamili'].'';
// 	}
// 	if($row['bangsa']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Bangsa : </b>'.$row['bangsa'].'';
// 	}
// 	if($row['genus']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Genus : </b>'.$row['genus'].'';
// 	}
// 	if($row['spesies']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Spesies : </b>'.$row['spesies'].'';
// 	}
// 	if($row['subspesies']!=""){
// 	    echo '<p style="text-align:left;font-size:20px;"><b>Subspesies : </b>'.$row['subspesies'].'';
// 	}
// 	echo '<p style="text-align:justify;font-size:20px;"><b>Deskripsi : </b>';
// 	echo '<p style="text-align:justify;font-size:20px;">'.$row['deskripsi'];
?>