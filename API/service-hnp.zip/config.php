<?php
	define('DB_SERVER', 'localhost');
   	define('DB_USERNAME', 'misbakhu_survey');
   	define('DB_PASSWORD', 'Survey12345');
   	define('DB_DATABASE', 'misbakhu_hnp');
   	$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   	
   	// /* check connection */
    // if (mysqli_connect_errno()) {
    //     printf("Connect failed: %s\n", mysqli_connect_error());
    //     exit();
    // }
    
    // if (!mysqli_query($db, "SET a=1")) {
    //     printf("Errormessage: %s\n", mysqli_error($db));
    // }
    
    // /* close connection */
    // mysqli_close($db);
?>